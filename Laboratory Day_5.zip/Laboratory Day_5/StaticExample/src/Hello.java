
public class Hello {
	
	public static void show(){
		System.out.println("Hello");
	}

}
