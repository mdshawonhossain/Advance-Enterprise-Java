
public class App {

	public static void main(String[] args) {
		//Hello obj1 = new Hello();
		//Hello.show();
		Student s1 = new Student();
		s1.setId(10);
		//System.out.println(s1);
		s1.setName("R");
		//s1.setUniversity("VU");
		//System.out.println(s1);
		
		Student s2 = new Student();
		s2.setId(11);
		s2.setName("S");
		s2.setUniversity("VU");
		//System.out.println(s1);
		System.out.println(s2);
		
	}

}
