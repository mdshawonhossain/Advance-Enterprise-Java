
public class Test {
	public static void main(String[]args){
		Student s = new Student();
		
		s.setId(10);
		s.setName("z");
		
       Course c = new Course();
		
		s.setId(10);
		s.setName("java");
		
		System.out.println(s);
		System.out.println(c);
		
	}

}
