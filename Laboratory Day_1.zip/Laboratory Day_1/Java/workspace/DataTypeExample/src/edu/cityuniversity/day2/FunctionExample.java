package edu.cityuniversity.day2;

public class FunctionExample {

	public static void main(String[] args) {
		
		int a = 10;
		int b =20;
		
		System.out.println(addition(a,b));
		
	}
	
	public static int addition(int a , int b){
		return a+b;
	}

}
