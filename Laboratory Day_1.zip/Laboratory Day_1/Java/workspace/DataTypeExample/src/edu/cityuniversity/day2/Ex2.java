package edu.cityuniversity.day2;

public class Ex2 {

	public static void main(String[] args) {
		
		int age = 16;
		
		if(age>=18){
			System.out.println("He/She is adult");
		}else{
			
			System.out.println("He/She is ont adult");
		}
		

	}

}
