package edu.cityuniversity.day1;

public class Ex1 {

	public static void main(String[] args) {

		int a =10;
		int b = 20;
		
		int sum = a+b;
		
		boolean yes = false;
		
		
		if(yes){
			System.out.println("Sum is :"+sum);
		}
		
	}

}
