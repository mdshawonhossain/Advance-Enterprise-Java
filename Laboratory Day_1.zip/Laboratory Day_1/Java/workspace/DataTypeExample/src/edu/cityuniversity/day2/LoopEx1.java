package edu.cityuniversity.day2;

public class LoopEx1 {
	
	public static void main(String[] args) {
		
	/*	for(int i=0;i<=10;i++){
			
			System.out.println(i);
		}
		*/
		// Single line comments 
		int i =0;
		while(i<10){
			System.out.println(i);
			i++;
		}
	}

}
