
public class BRAC extends Bank{

	@Override
	public double getInterest() {
		return 9;
	}

}
