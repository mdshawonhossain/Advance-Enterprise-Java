
public class AbstractionTest {

	public static void main(String[] args) {
		
		Bank b = new BRAC();
		System.out.println(b.getInterest());
	}

}
