
public abstract class Bank {
	
	public abstract double getInterest();

}
