package com.cityu;

public class Payment {
	
	public void showPayment(double amount){
		
		System.out.println("Payment amout "+amount);
		
	}

	public void showPayment(){
		
		System.out.println("No Payment ");
		
	}
}
