package com.cityUniversity.model;

public interface Payment {
	
	public void payment(double amount);

}
