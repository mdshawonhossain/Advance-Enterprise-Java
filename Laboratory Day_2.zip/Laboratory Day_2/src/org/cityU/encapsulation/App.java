package org.cityU.encapsulation;

public class App {

	public static void main(String[] args) {
		Student shaon = new Student();
		shaon.setStdId(100);
		shaon.setStdname("Shaon");
		shaon.setCgpa(3.9);
		System.out.println(shaon);
		
		Student s1 = new Student();
		s1.setStdId(200);
		s1.setStdname("S");
		s1.setCgpa(4);
		
		System.out.println(s1);
	}

}
